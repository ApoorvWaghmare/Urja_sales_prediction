import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-region-component',
  templateUrl: './region-component.component.html',
  styleUrls: ['./region-component.component.css']
})
export class RegionComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
 
    


      }


  }


