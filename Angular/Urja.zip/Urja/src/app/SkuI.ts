export interface SkuI
{
    skuId:number,
    catId:number,
    quantity:number,
    quantityUnit:string,
    piecesPerBox:number,
    
}