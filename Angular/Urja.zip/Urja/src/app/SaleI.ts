export interface SaleI{
    saleId:number;
    sale:number;
    skuId:number;
    date:string;
    distributionId:number;
    deleted:boolean;
}