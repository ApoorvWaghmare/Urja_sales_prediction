export interface CategoryI{

    catId:number;
    catName:String;
    

    
}