export interface RegionI
{
    id:number;
    name:string;
}